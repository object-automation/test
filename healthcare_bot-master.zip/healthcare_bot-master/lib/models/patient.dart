class Patient {
//These are the values that this Demo model can store
  late final int age_user;
  late final String user;
  late final String gender;
  late final String diagnosis;

//default Constructor
  Patient(int age, String name, String gender, String diagnosis) {
    this.age_user = age;
    this.user = name;
    this.gender = gender;
    this.diagnosis = diagnosis;
  }
}


/*
 List<Patient> patient_data = [
    Patient(20, "Ramesh", "Male", "Head pain"),
    Patient(22, "Aman", "Male", "Head pain"),
    Patient(28, "Rohan", "Male", "Head pain"),
    Patient(30, "Geeta", "Fem.ale", "Head pain"),
    Patient(51, "Mohan", "Male", "Head pain"),
    Patient(29, "Nidhi", "Female", "Head pain"),
    Patient(10, "Rita", "Female", "Head pain"),
    Patient(23, "Raj", "Male", "Head pain"),
  ];

  */

// ignore: non_constant_identifier_names

