import 'package:flutter/material.dart';

class TextFeildWithIcon extends StatelessWidget {
  const TextFeildWithIcon({Key? key, required this.a, required this.title, required this.r})
      : super(key: key);
  final Icon a;
  final String title;
  final bool r;
  @override
  Widget build(BuildContext context) {
    return Container(
        child: TextFormField(
      maxLength: 38,
      decoration: InputDecoration(
        hintText: title,
        icon: a,
      ),
      obscureText: r,
    ));
  }
}
