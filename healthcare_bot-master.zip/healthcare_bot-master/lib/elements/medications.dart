import 'package:flutter/material.dart';

class Medication extends StatefulWidget {
  const Medication({Key? key}) : super(key: key);

  @override
  _MedicationState createState() => _MedicationState();
}

class _MedicationState extends State<Medication> {
  final _formKey = GlobalKey<FormState>();
  var _medController = TextEditingController();
  static List<String?> currMedList = [null];

  @override
  void initState() {
    super.initState();
    _medController = TextEditingController();
  }

  @override
  void dispose() {
    _medController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20.0, 0, 20, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _getList(),
        ),
      ),
    );
  }

  /// get firends text-fields
  List<Widget> _getList(){
    List<Widget> medicalTextFields = [];
    for(int i=0; i<currMedList.length; i++){
      medicalTextFields.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            child: Row(
              children: [
                Expanded(child: new MedicationTextField(i)),
                SizedBox(width: 6,),
                // we need add button at last friends row
                _addRemoveButton(i == currMedList.length-1, i, currMedList.length-1),
              ],
            ),
          )
      );
    }
    return medicalTextFields;
  }

  /// add / remove button
  Widget _addRemoveButton(bool add, int index, int len){

    return InkWell(
      onTap: (){
        if(add){
          // add new text-fields at the top of all textfields
          currMedList.insert(len, null);
          currMedList.insert(len + 1, currMedList.removeAt(len));
        }
        else currMedList.removeAt(index);
        setState((){});
      },
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: (add) ? Colors.green : Colors.red,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Icon((add) ? Icons.add : Icons.remove, color: Colors.white,),
      ),
    );
  }
}

class MedicationTextField extends StatefulWidget {
  int index;
  MedicationTextField(this.index);

  @override
  _MedicationTextFieldState createState() => _MedicationTextFieldState();
}

class _MedicationTextFieldState extends State<MedicationTextField> {
  var _medController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _medController = TextEditingController();
  }

  @override
  void dispose() {
    _medController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      _medController.text = _MedicationState.currMedList[widget.index] ?? '';
    });

    return TextFormField(
      controller: _medController,
      onChanged: (v) => _MedicationState.currMedList[widget.index] = v,
      decoration: InputDecoration(
          hintText: 'Enter '
      ),
      validator: (v){
        if(v!.trim().isEmpty) return 'Please enter something';
        return null;
      },
    );
  }
}
