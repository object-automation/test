import 'package:flutter/material.dart';
import 'package:proto_1/screens/grid_screen.dart';
import 'package:proto_1/screens/login.dart';
import 'package:proto_1/screens/map.dart';
import 'package:proto_1/screens/patient_profile.dart';
import 'package:proto_1/screens/upcoming_app.dart';

class RaisedButtonWithBorder extends StatelessWidget {
  const RaisedButtonWithBorder({Key? key, required this.title})
      : super(key: key);
  final String title;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8,
      height: 65,
      decoration: const BoxDecoration(
        color: Colors.lightBlueAccent,
        borderRadius: BorderRadius.all(Radius.circular(60)),
      ),
      child: Center(
          child: Text(
        title,
        style: const TextStyle(
            color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
      )),
    );
  }
}

class LanguageButton extends StatelessWidget {
  final String title, code;
  final Future<void> Function(String, dynamic) function1;
  const LanguageButton(
      {Key? key,
      required this.title,
      required this.function1,
      required this.code})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100.0,
      width: 200.0,
      child: ElevatedButton(
          onPressed: () {
            function1("language", code);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => LoginPage(
                          title: "Login",
                        )));
          },
          style: ElevatedButton.styleFrom(primary: Colors.lightBlueAccent),
          child: Text(
            title,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
          )),
    );
  }
}

class UpcomingAppointments extends StatelessWidget {
  final String title;
  const UpcomingAppointments({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          shape: StadiumBorder(),
        ),
        onPressed: () {Navigator.push(
                context, MaterialPageRoute(builder: (context) => UpcomingAppointmentsPage()));},
        child: Text(title));
  }
}

class EmergencyButton extends StatelessWidget {
  const EmergencyButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90.0,
      child: FittedBox(
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => MapMini()));
          },
          child: const Text('Emergency', style: TextStyle(fontSize: 7.0)),
          backgroundColor: Colors.red,
        ),
      ),
    );
  }
}

class OptButton extends StatelessWidget {
  final title;
  void Function() x = () {};
  OptButton({Key? key, this.title, required this.x}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 50,
        width: 230,
        child: ElevatedButton(
          onPressed: x,
          child: Text(title),
        ));
  }
}

class UserProfile extends StatelessWidget {
  const UserProfile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    ProfilePatient(title: "Patient Profile")));
      },
      child: Container(
          child: const Icon(
        Icons.person,
        size: 30,
      )),
    );
  }
}

class Wearable extends StatelessWidget {
  const Wearable({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    GridScreen()));
      },
      child: Container(
        child: const Icon(
          Icons.watch,
          size: 30,
        )
      ),
    );
  }
}

class NumericStepButton extends StatefulWidget {
  final int minValue;
  final int maxValue;

  final ValueChanged<int> onChanged;

  const NumericStepButton(
      {Key? key,
      this.minValue = 0,
      this.maxValue = 10,
      required this.onChanged})
      : super(key: key);

  @override
  State<NumericStepButton> createState() {
    return _NumericStepButtonState();
  }
}

class _NumericStepButtonState extends State<NumericStepButton> {
  int counter = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            icon: Icon(
              Icons.remove,
              color: Theme.of(context).colorScheme.secondary,
            ),
            padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 18.0),
            iconSize: 32.0,
            color: Theme.of(context).primaryColor,
            onPressed: () {
              setState(() {
                if (counter > widget.minValue) {
                  counter--;
                }
                widget.onChanged(counter);
              });
            },
          ),
          Text(
            '$counter',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.black87,
              fontSize: 18.0,
              fontWeight: FontWeight.w500,
            ),
          ),
          IconButton(
            icon: Icon(
              Icons.add,
              color: Theme.of(context).colorScheme.secondary,
            ),
            padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 18.0),
            iconSize: 32.0,
            color: Theme.of(context).primaryColor,
            onPressed: () {
              setState(() {
                if (counter < widget.maxValue) {
                  counter++;
                }
                widget.onChanged(counter);
              });
            },
          ),
        ],
      ),
    );
  }
}
