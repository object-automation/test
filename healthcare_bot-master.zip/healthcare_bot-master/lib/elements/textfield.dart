import 'package:flutter/material.dart';

class textfield extends StatefulWidget {
  const textfield({Key? key}) : super(key: key);

  @override
  _textfieldState createState() => _textfieldState();
}

class _textfieldState extends State<textfield> {
  final heightController = TextEditingController();
  final weightController = TextEditingController();

  @override
  void dispose() {
    heightController.dispose();
    weightController.dispose();
    super.dispose();
  }

  @override
  Widget buildHeight() => Padding(
    padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 10.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Height: ', style: TextStyle(
          color: Colors.grey[700],
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),),
        const SizedBox(height: 12),
        TextField(
          controller: heightController,
          decoration: InputDecoration(
            hintText: 'Enter height in cms.',
            hintStyle: TextStyle(color: Colors.grey[500]),
            border: OutlineInputBorder(),
          ),
          style: TextStyle(color: Colors.black),
          keyboardType: TextInputType.number,
        ),
      ],
    ),
  );

  @override
  Widget buildWeight() => Padding(
    padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 10.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Weight: ', style: TextStyle(
          color: Colors.grey[700],
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),),
        const SizedBox(height: 12),
        TextField(
          controller: weightController,
          decoration: InputDecoration(
            hintText: 'Enter weight in kgs.',
            hintStyle: TextStyle(color: Colors.grey[500]),
            border: OutlineInputBorder(),
          ),
          style: TextStyle(color: Colors.black),
          keyboardType: TextInputType.number,
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 10,),
        buildHeight(),
        SizedBox(height: 20,),
        buildWeight()
      ],
    );
  }
}
