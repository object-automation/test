import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TimeWidget extends StatefulWidget {
  final String title;
  const TimeWidget({Key? key, required this.title}) : super(key: key);

  @override
  _TimeWidgetState createState() => _TimeWidgetState();
}

class _TimeWidgetState extends State<TimeWidget> {
  TimeOfDay? date;

  String getText() {
    if (date == null) {
      return 'Please Select A Time Slot';
    } else {
      return '${date?.hour}:${date?.minute}';
    }
  }

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20.0, 20.0, 10.0, 3.0),
            child: Text(
              widget.title,
              style: TextStyle(
                color: Colors.grey[700],
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Padding(
            padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 5.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: Size.fromHeight(40),
                primary: Colors.white,
              ),
              child: FittedBox(
                child: Text(
                  getText(),
                  style: TextStyle(fontSize: 20, color: Colors.black),
                ),
              ),
              onPressed: () {
                pickDate(context);
              },
            ),
          ),
        ],
      );

  Future pickDate(BuildContext context) async {
    final initialDate = TimeOfDay.now();
    final TimeOfDay? newTime = await showTimePicker(
  context: context,
  initialTime: TimeOfDay(hour: 7, minute: 15),
);

    if (newTime == null) return;

    setState(() => date = newTime);
  }
}
