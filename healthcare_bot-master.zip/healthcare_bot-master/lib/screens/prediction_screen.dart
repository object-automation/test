import 'package:flutter/material.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:proto_1/screens/consult_doctor.dart';
import 'home_remedies.dart';

class PredictedScreen extends StatelessWidget {
  final String disease;
  final int priority;
  final List remedy;
  const PredictedScreen(
      {Key? key,
      required this.disease,
      required this.priority,
      required this.remedy})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Prediction Screen"),
            UserProfile(),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  const Text(
                    "We think you have : ",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    disease,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              PriorityIndicator(
                priority: priority,
              ),
            ],
          ),
          Column(
            children: [
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ConsultDoctor()));
                },
                child: Padding(
                  padding: EdgeInsets.only(left: 23, right: 23, bottom: 30),
                  child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(8)),
                    child: Center(
                        child: Text(
                      "It is suggested that you consult a doctor",
                      style: TextStyle(fontSize: 26, fontWeight: FontWeight.w500),
                    )),
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Home_remedy(
                                remedy: remedy,
                              )));
                },
                child: Container(
                  decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(8)),
                  child: Text(
                    "Home Remedies",
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class PriorityIndicator extends StatelessWidget {
  final int priority;
  const PriorityIndicator({Key? key, required this.priority}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(
          alignment: (priority == 1)
              ? AlignmentDirectional.topCenter
              : AlignmentDirectional.center,
          children: [
            Container(
              height: 100,
              width: 2,
              color: (priority == 1) ? Colors.red : Colors.green,
            ),
            InkResponse(
              child: Container(
                width: 10,
                height: 10,
                //color: Colors.black,
                decoration: BoxDecoration(
                  color: Colors.black,
                  shape: BoxShape.circle,
                  //borderRadius: BorderRadius.circular(7)
                ),
              ),
            )
          ]),
    );
  }
}
