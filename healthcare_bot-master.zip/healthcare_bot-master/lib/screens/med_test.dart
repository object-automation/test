import 'dart:async';
import 'dart:convert';
import 'package:proto_1/elements/hosp_name.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class MedTest extends StatefulWidget {
  const MedTest({Key? key}) : super(key: key);

  @override
  _MedTestState createState() => _MedTestState();
}

class _MedTestState extends State<MedTest> {
  String url = "https://discover.search.hereapi.com/v1/discover";
  String latitude = "18.5074";
  String longitude = "73.807";
  String api_key = 'oq0GkZ7rld2zgcxuOM5-Tq3eGQRQQvDj-nnlDz0V7BE';
  String query = 'pathology+labs';
  String limit = "5";
  final Completer<WebViewController> _completer =
      Completer<WebViewController>();
  late String hospitalOne = "Hello";
  final String url2 = "https://www.google.com/maps/search/pathology+labs+near+me/";
  late String hospitalOne_address;
  late String hospitalOne_latitude;
  late String hospitalOne_longitude;
  late List hospdata;
  late List hospdata1 = [
    {
      "title": "Sahyadri Hospital-ER",
      "id": "here:pds:place:356tek3r-efd819c2ed0c6281d720aad84ec2ba1e",
      "ontologyId": "here:cm:ontology:hospital",
      "resultType": "place",
      "address": {
        "label": "Sahyadri Hospital-ER, Paud Road, Kothrud, Pune 411038, India",
        "countryCode": "IND",
        "countryName": "India",
        "stateCode": "MH",
        "state": "Maharashtra",
        "county": "Pune",
        "city": "Pune",
        "district": "Kothrud",
        "street": "Paud Road",
        "postalCode": "411038"
      },
      "position": {"lat": 18.5073, "lng": 73.80593},
      "access": [
        {"lat": 18.50732, "lng": 73.80593}
      ],
      "distance": 113,
      "categories": [
        {"id": "800-8000-0159", "name": "Hospital", "primary": true}
      ],
      "references": [
        {
          "supplier": {"id": "core"},
          "id": "1193766999"
        }
      ]
    }
  ];
  Map<String, String> params = {};

  Future<void> createparam() async {
    params['apikey'] = api_key;
    params['q'] = query;
    params['limit'] = limit;
    params['at'] = latitude + "," + longitude;
    Uri queryString =
        Uri.https('discover.search.hereapi.com', '/v1/discover', params);
    var response = await http.get(queryString);
    //print(response.body);
    var data = await jsonDecode(response.body);

    setState(() {
      hospdata1 = data['items'];
      //print(hospdata);
    });
  }

  @override
  void initState() {
    createparam();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: Text("Labs Nearby"),),
        body: Center(
          child: Column(
            children: [
              Container(
                height: 500,
                width: 300,
                child: WebView(initialUrl: url2,
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: ((WebViewController webViewController) {
                  _completer.complete(webViewController);})
                ),
              ),
              SizedBox(height: 20,),
              Text("5 labs in your vicinity are:"),
              SizedBox(height: 25,),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children:
                          hospdata1.map((e) => Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: HospName(name: e['title']),
                          )).toList()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
