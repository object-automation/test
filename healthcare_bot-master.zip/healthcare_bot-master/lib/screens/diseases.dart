import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';

class Diseases extends StatefulWidget {
  const Diseases({Key? key}) : super(key: key);

  @override
  _DiseasesState createState() => _DiseasesState();
}

class _DiseasesState extends State<Diseases> {
  final _formKey = GlobalKey<FormState>();
  var _nameController = TextEditingController();
  static List<String?> currList = [null];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20.0, 0, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _getList(),
          ),
        ),
    );
  }

  /// get firends text-fields
  List<Widget> _getList(){
    List<Widget> medicalTextFields = [];
    for(int i=0; i<currList.length; i++){
      String? dropdownvalue;
      var severity =  ['High','Medium','Low'];
      allTextFields obj = new allTextFields(i, dropdownvalue);
      medicalTextFields.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 0.0),
            child: Row(
              children: [
                Expanded(child: obj),
                SizedBox(width: 6,),
                Container(
                  width: 120,
                  padding: const EdgeInsets.fromLTRB(30.0, 0.0, 0.0, 13.0),
                  child: DropdownButtonFormField(
                    decoration: InputDecoration(
                        labelText: 'Select'
                    ),
                    value: dropdownvalue ?? null,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    iconSize: 36,
                    isExpanded: true,
                    icon: Icon(Icons.keyboard_arrow_down),
                    items: severity.map((String svr) {
                      return DropdownMenuItem(
                          value: svr,
                          child: Text(svr)
                      );
                    }
                    ).toList(),
                    onChanged: (String? newValue){
                      setState(() {
                        dropdownvalue = newValue;
                      });
                    },
                  ),
                ),
                SizedBox(width: 10,),
                // we need add button at last friends row
                _addRemoveButton(i == currList.length-1, i, currList.length-1),
              ],
            ),
          )
      );
      obj.value = dropdownvalue;
    }
    return medicalTextFields;
  }

  /// add / remove button
  Widget _addRemoveButton(bool add, int index, int len){

    return InkWell(
      onTap: (){
        if(add){
          // add new text-fields at the top of all textfields
          currList.insert(len, null);
          currList.insert(len + 1, currList.removeAt(len));
        }
        else currList.removeAt(index);
        setState((){});
      },
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: (add) ? Colors.green : Colors.red,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Icon((index == len) ? Icons.add : Icons.remove, color: Colors.white,),
      ),
    );
  }
}

class allTextFields extends StatefulWidget {
  int index;
  String? value;
  allTextFields(this.index, this.value);
  @override
  _allTextFieldsState createState() => _allTextFieldsState();
}

class _allTextFieldsState extends State<allTextFields> {
  var _nameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
  // print(_nameController);
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      _nameController.text = _DiseasesState.currList[widget.index] ?? '';
    });

    return TextFormField(
      controller: _nameController,
      onChanged: (v) => _DiseasesState.currList[widget.index] = v,
      decoration: InputDecoration(
          hintText: 'Enter '
      ),
      validator: (v){
        if(v!.trim().isEmpty) return 'Please enter something';
        return null;
      },
    );
  }
}


