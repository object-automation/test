import 'dart:async';

import 'package:flutter/material.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:webview_flutter/webview_flutter.dart';

class UpcomingAppointmentsPage extends StatefulWidget {
  const UpcomingAppointmentsPage({Key? key}) : super(key: key);

  @override
  _UpcomingAppointmentsPageState createState() =>
      _UpcomingAppointmentsPageState();
}

class _UpcomingAppointmentsPageState extends State<UpcomingAppointmentsPage> {
  @override
  final TextStyle a = new TextStyle(fontWeight: FontWeight.bold, fontSize: 20);
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: const [
            Text("Upcoming Appointments"),
            UserProfile(),
          ],
        ),
      ),
      body: Column(
        children: [
          Text("Description and Agenda", style: a,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                  child: Text("Video Call with Dr. XYZ on 31/12/21 at 4pm",)),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => VideoCall(
                              url1: "https://meet.google.com/fnq-ozfq-nen")));
                },
                child: Container(
                  height: 80,
                  width: 100,
                  child: Center(child: Text("Join Video Call")),
                  decoration: BoxDecoration(color: Colors.green),
                ),
              ),
            ],
          ),
          Text("Previous Appointments", style: a,),
        ],
      ),
    );
  }
}

class VideoCall extends StatelessWidget {
  VideoCall({Key? key, required this.url1}) : super(key: key);
  final String url1;
  final Completer<WebViewController> _completer =
      new Completer<WebViewController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: 500,
        width: 500,
        child: WebView(
            initialUrl: url1,
            javascriptMode: JavascriptMode.unrestricted,
            onWebViewCreated: ((WebViewController webViewController) {
              _completer.complete(webViewController);
            })),
      ),
    );
  }
}
