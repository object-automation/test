import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:proto_1/screens/chatbot_screen.dart';
import 'package:proto_1/screens/consult_doctor.dart';
import 'package:proto_1/screens/med_test.dart';
import 'package:proto_1/screens/prediction_screen.dart';
import 'package:proto_1/screens/upload.dart';

class MainHome extends StatefulWidget {
  const MainHome({Key? key}) : super(key: key);

  @override
  State<MainHome> createState() => _MainHomeState();
}

class _MainHomeState extends State<MainHome> {
  dynamic x;
  Map<String, dynamic> langs1 = {};
  Future<void> langselect() async {
    Directory appDocDir = await getApplicationDocumentsDirectory();
    File file = await File("${appDocDir.path}/cache.json");
    x = await file.readAsString();
    x = await jsonDecode(x);
    print(x);
    final String response =
        await rootBundle.loadString('assets/' + x["language"] + '.json');
    final data = await jsonDecode(response);
    setState(() {
      langs1 = data;
    });
  }

  @override
  void initState() {
    langselect();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(langs1["H App"] ?? "Healthcare App1"),
            Row(
              children: [
                UserProfile(),
                SizedBox(width: 20,),
                Wearable(),
              ],
            ),

          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
                height: 100,
                width: 200,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => ChatbotScreen(title: "Chatbot")));
                  },
                  child: Text(langs1["Not Well"] ?? "Not Feeling Well"),
                )),
            Container(
                height: 100,
                width: 200,
                child: ElevatedButton(
                  onPressed: () {Navigator.push(context,
                        MaterialPageRoute(builder: (context) => ConsultDoctor()));},
                  child: Text(langs1["Upload R"] ?? "Book Video Consultation"),
                )),
            Container(
                height: 100,
                width: 200,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Upload()));
                  },
                  child: Text(langs1["Upload X"] ?? "Upload X-Ray"),
                )),
            Container(
                height: 100,
                width: 200,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MedTest()));
                  },
                  child: Text(langs1["Book T"] ?? "Book a medical test"),

                )),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  UpcomingAppointments(
                      title: langs1["Upcoming A"] ?? "Upcoming Appointments"),
                  EmergencyButton(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
