import 'package:flutter/material.dart';
import 'package:proto_1/elements/buttons.dart';

class Home_remedy extends StatelessWidget {
  final List remedy;

  const Home_remedy({Key? key, required this.remedy}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("HOME REMEDIES"),

        //<Widget>[]
      ), //AppBar
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 20, bottom: 25),
            child: Text(
              "Take Following Measures :",
              style: TextStyle(
                  color: Colors.blue[600],
                  fontWeight: FontWeight.bold,
                  fontSize: 28),
            ),
          ),
          Expanded(
            child: ListView.builder(
                itemCount: remedy.length,
                itemBuilder: (context, index) => show_remedy(
                      remedy[index].toString(),
                      index,
                    )),
          ),
          Padding(
              padding: EdgeInsets.only(bottom: 10), child: EmergencyButton()),
        ],
      ),
    );
  }
}

// ignore: non_constant_identifier_names
Widget show_remedy(String message, int data) {
  // ignore: dead_code
  return Container(
    child: Padding(
      padding: EdgeInsets.all(10),
      child: Text(
        "${data + 1} . ${message}",
        style: TextStyle(
            color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20),
      ),
    ),
  );
}
