import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:proto_1/elements/buttons.dart';
import 'dart:io';
import 'dart:convert';
import 'package:path_provider/path_provider.dart';

class LanguageSelect extends StatefulWidget {
  const LanguageSelect({Key? key}) : super(key: key);

  @override
  State<LanguageSelect> createState() => _LanguageSelectState();
}

class _LanguageSelectState extends State<LanguageSelect> {
  @override
  Future<void> _writeJson(String key, dynamic value) async {
    Directory appDocDir = await getApplicationDocumentsDirectory();
    //print(appDocDir);
    File file = await File("${appDocDir.path}/cache.json");
    Map<String, dynamic> _newJson = {key: value};
    Map<String, dynamic> _json = {};
    String _jsonString;
    _json.addAll(_newJson);
    _jsonString = await jsonEncode(_json);
    await file.writeAsString(_jsonString);
    setState(() {
    });
    //print(await file.readAsStringSync());
  }

  Widget build(BuildContext context) {
    final List<Map<String, String>> langs = [
      {"name": "English", "code": "en"},
      {"name": "Hindi", "code": "hi"}
    ];
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text('AI Health Care'),
        centerTitle: true,
        backgroundColor: Colors.grey[800],
      ),
      floatingActionButton: EmergencyButton(),
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: langs
                .map((e) => LanguageButton(
                    title: e["name"] ?? "English",
                    code: e["code"] ?? "en",
                    function1: _writeJson))
                .toList()),
      ),
    );
  }
}
