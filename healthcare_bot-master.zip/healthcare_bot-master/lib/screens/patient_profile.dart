import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';


List<PatientData> getChartData() {
  final List<PatientData> chartData = [
    PatientData('Asthama', 60),
    PatientData('Blood Pressure', 80),
    PatientData('Diabaetes', 90)
  ];
  return chartData;
}

List<PatientData2> getChartData2() {
  final List<PatientData2> chartData = [
    PatientData2('Fruits', 30),
    PatientData2('Protein', 23),
    PatientData2('Vegetables', 18),
    PatientData2('Dairy', 15),
    PatientData2('Grains', 9),
    PatientData2('Other', 5)
  ];
  return chartData;
}

class PatientData {
  PatientData(this.disease, this.severity);
  final String disease;
  final int severity;
}

class PatientData2 {
  PatientData2(this.disease, this.severity);
  final String disease;
  final int severity;
}


class ProfilePatient extends StatefulWidget {
  ProfilePatient({Key? key, required this.title}) : super(key: key);
  final String title;
  @override
  _ProfilePatientState createState() => _ProfilePatientState();
}

class _ProfilePatientState extends State<ProfilePatient> {
  late List<PatientData> _chartData;
  late List<PatientData2> _chartData2;
  late TooltipBehavior _tooltipBehavior;

  @override
  void initState() {
    _chartData = getChartData();
    _chartData2 = getChartData2();
    _tooltipBehavior = TooltipBehavior(enable: true);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Your Profile"),
            
          ],
        ),
      ),
        body: SingleChildScrollView(
          child: Center(
              child: Column(children: <Widget>[
              Container(
          child: SfCircularChart(
            title: ChartTitle(
              text: 'Past Diseases With Severity ',
            ),
            legend: Legend(
                isVisible: true, overflowMode: LegendItemOverflowMode.wrap),
            tooltipBehavior: _tooltipBehavior,
            series: <CircularSeries>[
              RadialBarSeries<PatientData, String>(
                  dataSource: _chartData,
                  xValueMapper: (PatientData data, _) => data.disease,
                  yValueMapper: (PatientData data, _) => data.severity,
                  dataLabelSettings: DataLabelSettings(isVisible: true),
                  enableTooltip: true,
                  maximumValue: 100)
            ],
          ),
              ),
              Container(
          child: SfCircularChart(
            title: ChartTitle(
              text: 'Recommended Diet',
            ),
            legend: Legend(
                isVisible: true, overflowMode: LegendItemOverflowMode.wrap),
            tooltipBehavior: _tooltipBehavior,
            series: <CircularSeries>[
              PieSeries<PatientData2, String>(
                  dataSource: _chartData2,
                  xValueMapper: (PatientData2 data, _) => data.disease,
                  yValueMapper: (PatientData2 data, _) => data.severity,
                  dataLabelSettings: DataLabelSettings(isVisible: true),
                  enableTooltip: true)
            ],
          ),
              )
            ])),
        ));
  }
}
