import 'package:flutter/material.dart';
import 'package:proto_1/screens/graph_screen.dart';

class GridScreen extends StatelessWidget {
  const GridScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Parameters"),
      ),
      body: SingleChildScrollView(
        child: Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            "Steps",
            "Walking + Running Distance",
            "Workouts",
            "Heart Rate",
            "Spo2",
            "Mindful Minutes",
            "Flights Climbed",
            "Weight",
            "Height",
            "Non wearable data analysis"
          ].map((f) => GestureDetector(
            child: Container(
                margin: const EdgeInsets.only(
                    left: 5.0, right: 5.0, top: 10.0, bottom: 10.0),
                decoration: BoxDecoration(
                  border: Border.all(width: 1.0),
                  borderRadius: const BorderRadius.all(Radius.circular(
                      10.0)
                  ),
                ),
              child: ListTile(
                title: Text(f),
                trailing: const Icon(
                  Icons.arrow_forward_ios_rounded, color: Colors.blue,
                ),
              ),
            ),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) => const GraphScreen()));
            },
          ))
              .toList(),
        ),
      ),
    );
  }
}
