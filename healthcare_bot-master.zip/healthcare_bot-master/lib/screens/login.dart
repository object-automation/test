import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:proto_1/screens/signup.dart';
import 'profile.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  dynamic x;
  Map<String, dynamic> langs1 = {};

  Future<void> langselect() async {
    Directory appDocDir = await getApplicationDocumentsDirectory();
    File file = await File("${appDocDir.path}/cache.json");
    x = await file.readAsString();
    x = await jsonDecode(x);
    print(x);
    setState(() {});
    final String response =
        await rootBundle.loadString('assets/' + x["language"] + '.json');
    final data = await jsonDecode(response);
    setState(() {
      langs1 = data;
    });
  }

  @override
  void initState() {
    langselect();
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: EmergencyButton(),
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              TextFormField(
                maxLength: 38,
                decoration: InputDecoration(
                  hintText: langs1["Phone"],
                  icon: Icon(Icons.phone),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              TextFormField(
                maxLength: 38,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: langs1["Password"],
                  icon: Icon(Icons.password_sharp),
                ),
              ),
              const SizedBox(
                height: 100,
              ),
              InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => User_profiles()));
                  },
                  child: RaisedButtonWithBorder(
                      title: langs1["Sign In"] ?? "Sign In1")),
              const SizedBox(
                height: 5,
              ),
              RaisedButtonWithBorder(
                  title:
                      langs1["Sign In With Google"] ?? "Sign In With Google1"),
              const SizedBox(
                height: 5,
              ),
              GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SignupPage(title: "SignUp")));
                  },
                  child: RaisedButtonWithBorder(
                      title: langs1["Sign Up"] ?? "Sign Up1")),
              const SizedBox(
                height: 30,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
