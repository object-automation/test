import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:proto_1/screens/home.dart';
import '../elements/date.dart';
import '../elements/textfield.dart';
import 'diseases.dart';
import '../elements/medications.dart';

class RegistrationForm extends StatefulWidget {
  const RegistrationForm({Key? key}) : super(key: key);

  @override
  _RegistrationFormState createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  String? dropdownvalue;
  var gender = ['Male', 'Female', 'Other', 'Prefer not to say'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Medical Information'),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            DateWidget(title: 'Enter Date of Birth',),
            Container(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 10.0),
                      child: Row(
                        children: [
                          Text(
                            'Gender: ',
                            style: TextStyle(
                              color: Colors.grey[700],
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Container(
                            width: 300,
                            padding:
                                const EdgeInsets.fromLTRB(30.0, 0.0, 0.0, 13.0),
                            child: DropdownButtonFormField(
                              decoration: InputDecoration(labelText: 'Select'),
                              value: dropdownvalue ?? null,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                              iconSize: 36,
                              isExpanded: true,
                              icon: Icon(Icons.keyboard_arrow_down),
                              items: gender.map((String gdr) {
                                return DropdownMenuItem(
                                    value: gdr, child: Text(gdr));
                              }).toList(),
                              onChanged: (String? newValue) {
                                setState(() {
                                  dropdownvalue = newValue;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            textfield(),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 0.0),
                child: Text(
                  'Past Diseases: ',
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Diseases(),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 0.0),
                child: Text(
                  'Current Medications: ',
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Medication(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                RaisedButton(
                  child: Text(
                    'Skip',
                    style: TextStyle(fontSize: 20),
                  ),
                  shape: StadiumBorder(),
                  color: Theme.of(context).primaryColor,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  textColor: Colors.white,
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MainHome()));
                  },
                ),
                SizedBox(
                  width: 70,
                ),
                RaisedButton(
                  child: Text(
                    'Submit',
                    style: TextStyle(fontSize: 20),
                  ),
                  shape: StadiumBorder(),
                  color: Theme.of(context).primaryColor,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  textColor: Colors.white,
                  onPressed: () {},
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
