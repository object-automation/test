import 'package:flutter/material.dart';
import 'home.dart';

class User_profiles extends StatefulWidget {
  const User_profiles({Key? key}) : super(key: key);

  @override
  _User_profilesState createState() => _User_profilesState();
}

void navi(context) {
  Navigator.push(context, MaterialPageRoute(builder: (context) => MainHome()));
}

class _User_profilesState extends State<User_profiles> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select User'),

        //<Widget>[]
      ), //AppBar
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MainHome()));
                  },
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    radius: 75,
                    child: Text(
                      'USER 1',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ), //Text
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MainHome()));
                  },
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    radius: 75,
                    child: Text(
                      'USER 2',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ), //Text
                  ),
                )
              ],
            ),
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MainHome()));
                  },
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    radius: 75,
                    child: Text(
                      'USER 3',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ), //Text
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MainHome()));
                  },
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    radius: 75,
                    child: Text(
                      'USER 4',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ), //Text
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
