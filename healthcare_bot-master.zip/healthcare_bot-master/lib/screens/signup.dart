import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:proto_1/screens/home.dart';
import 'package:proto_1/screens/registration_form.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  @override
  dynamic x;
  int age = 21;
  Map<String, dynamic> langs1 = {};

  Future<void> langselect() async {
    Directory appDocDir = await getApplicationDocumentsDirectory();
    File file = await File("${appDocDir.path}/cache.json");
    x = await file.readAsString();
    x = await jsonDecode(x);
    print(x);
    setState(() {});
    final String response =
        await rootBundle.loadString('assets/' + x["language"] + '.json');
    final data = await jsonDecode(response);
    setState(() {
      langs1 = data;
    });
  }

  @override
  void initState() {
    langselect();
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: EmergencyButton(),
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              TextFormField(
                maxLength: 10,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: langs1["Please Enter Your N"],
                  icon: const Icon(Icons.phone),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              TextFormField(
                maxLength: 38,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: langs1["Please Enter Your P"],
                  icon: const Icon(Icons.password_sharp),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              TextFormField(
                keyboardType: TextInputType.number,
                maxLength: 3,
                decoration: InputDecoration(
                  hintText: langs1["Please Enter Your A"],
                  icon: const Icon(Icons.calendar_today),
                ),
              ),
              const SizedBox(
                height: 100,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => RegistrationForm()));
                },
                child: RaisedButtonWithBorder(
                    title: langs1["Receive OTP"] ?? "Receive OTP"),
              ), // TODO
              const SizedBox(
                height: 5,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
