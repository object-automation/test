import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:proto_1/elements/time.dart';
import 'dart:convert';
import 'dart:io';

import 'package:proto_1/elements/date.dart';

import 'map.dart';


class ConsultDoctor extends StatefulWidget {
  const ConsultDoctor({Key? key}) : super(key: key);

  @override
  _ConsultDoctorState createState() => _ConsultDoctorState();
}

class _ConsultDoctorState extends State<ConsultDoctor> {
  dynamic x;
  Map<String, dynamic> langs1 = {};
  Future<void> langselect() async {
    Directory appDocDir = await getApplicationDocumentsDirectory();
    File file = await File("${appDocDir.path}/cache.json");
    x = await file.readAsString();
    x = await jsonDecode(x);
    print(x);
    final String response =
        await rootBundle.loadString('assets/' + x["language"] + '.json');
    final data = await jsonDecode(response);
    setState(() {
      langs1 = data;
    });
  }

  @override
  void initState() {
    langselect();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(langs1["H App"] ?? "Healthcare App1"),
            UserProfile(),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(),
            child: Text("Select a date and your convenient timings to video consult a doctor", style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700), )),
          SizedBox(height:10),
          DateWidget(title: 'Select Date',),
          SizedBox(height:10),
          TimeWidget(title: 'Select Time Slot'),
          SizedBox(height:10),
          OptButton(title: "Book Video Call Consultation", x: () {  },),
          SizedBox(height:70),
          OptButton(title: "Visit a hospital instead", x: () { Navigator.push(
                context, MaterialPageRoute(builder: (context) => MapMini())); },),
          Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  UpcomingAppointments(
                      title: langs1["Upcoming A"] ?? "Upcoming Appointments"),
                  EmergencyButton(),
                ],
              ),
            ),

        ],
      ),
    );
  }
}
