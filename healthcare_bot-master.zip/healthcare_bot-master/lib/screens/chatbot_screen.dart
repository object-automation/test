import 'dart:convert';

import 'package:bubble/bubble.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:proto_1/screens/map.dart';
import 'package:proto_1/screens/prediction_screen.dart';

class ChatbotScreen extends StatefulWidget {
  ChatbotScreen({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  void initState() {
    messsages
        .insert(0, {"data": 0, "message": "Is this an emergency situation ?"});
  }

  var url = Uri.parse('http://345c-104-196-120-136.ngrok.io/chat');

  void req_api(query) async {
    await http.post(url, body: {
      "msg": query,
      "name": "naman",
    }).then((resp) {
      setState(() {
        if (query == "no") {
          Map<String, dynamic> response = jsonDecode(resp.body);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PredictedScreen(
                      disease: response['disease'],
                      priority: 1,
                      remedy: response['prec_list'])));
          print(response['disease']);
          print(response['precaution']);
        } else {
          print(resp.body);
          messsages.insert(0, {"data": 0, "message": resp.body});
        } //Todo
      });
    });
  }

  void response(query) async {
    setState(() {
      messsages.insert(0, {"data": 0, "message": "ok"});
    });
  }

  final messageInsert = TextEditingController();
  // ignore: deprecated_member_use
  List<Map> messsages = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Chat bot",
        ),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(top: 15, bottom: 10),
              child: Text(
                "Today, ${DateFormat("Hm").format(DateTime.now())}",
                style: TextStyle(fontSize: 20),
              ),
            ),
            Flexible(
                child: ListView.builder(
                    reverse: true,
                    itemCount: messsages.length,
                    itemBuilder: (context, index) => chat(
                        messsages[index]["message"].toString(),
                        messsages[index]["data"]))),
            SizedBox(
              height: 20,
            ),
            Divider(
              height: 5.0,
              color: Colors.blueAccent,
            ),
            Container(
              child: ListTile(
                leading: IconButton(
                  icon: Icon(
                    Icons.camera_alt,
                    color: Colors.blueAccent,
                    size: 35,
                  ),
                  onPressed: () {},
                ),
                title: Container(
                  height: 35,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color.fromRGBO(220, 220, 220, 1),
                  ),
                  padding: EdgeInsets.only(left: 15),
                  child: TextFormField(
                    controller: messageInsert,
                    decoration: InputDecoration(
                      hintText: "Enter a Message...",
                      hintStyle: TextStyle(color: Colors.black26),
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                    ),
                    style: TextStyle(fontSize: 16, color: Colors.black),
                    onChanged: (value) {},
                  ),
                ),
                trailing: IconButton(
                    icon: Icon(
                      Icons.send,
                      size: 30.0,
                      color: Colors.blueAccent,
                    ),
                    onPressed: () {
                      if (messageInsert.text.isEmpty) {
                        print("empty message");
                      } else {
                        setState(() {
                          messsages.insert(
                              0, {"data": 1, "message": messageInsert.text});
                        });
                        req_api(messageInsert.text);
                        messageInsert.clear();
                      }
                      FocusScopeNode currentFocus = FocusScope.of(context);
                      if (!currentFocus.hasPrimaryFocus) {
                        currentFocus.unfocus();
                      }
                    }),
              ),
            ),
            SizedBox(
              height: 15.0,
            )
          ],
        ),
      ),
    );
  }

  //for better one i have use the bubble package check out the pubspec.yaml

  Widget chat(String message, int data) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.only(left: 20, right: 20),
          child: Row(
            mainAxisAlignment:
                data == 1 ? MainAxisAlignment.end : MainAxisAlignment.start,
            children: [
              data == 0
                  ? Container(
                      height: 60,
                      width: 60,
                      child: CircleAvatar(
                        backgroundImage: AssetImage("assets/robot.jpg"),
                      ),
                    )
                  : Container(),
              Padding(
                padding: EdgeInsets.all(10.0),
                child: Bubble(
                    radius: Radius.circular(15.0),
                    color: data == 0 ? Colors.blue : Colors.orangeAccent,
                    elevation: 0.0,
                    child: Padding(
                      padding: EdgeInsets.all(2.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          SizedBox(
                            width: 10.0,
                          ),
                          Flexible(
                              child: Container(
                            constraints: BoxConstraints(maxWidth: 200),
                            child: Text(
                              message,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          )),
                        ],
                      ),
                    )),
              ),
              data == 1
                  ? Container(
                      height: 60,
                      width: 60,
                      child: CircleAvatar(
                        backgroundImage: AssetImage("assets/default.jpg"),
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
        message == "Would you like to add another symptom?" ||
                message == "Do you want to add symptom?"
            ? Container(
                width: MediaQuery.of(context).size.width * 0.5,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    ElevatedButton(
                        onPressed: () {
                          req_api("yes");
                        },
                        child: Text('YES')),
                    Padding(padding: EdgeInsets.all(10.0)),
                    ElevatedButton(
                        onPressed: () {
                          req_api("no");
                        },
                        child: Text('NO'))
                  ],
                ),
              )
            : Container(),
        message == "Is this an emergency situation ?"
            ? Container(
                width: MediaQuery.of(context).size.width * 0.5,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => MapMini()));
                        },
                        child: Text('YES')),
                    Padding(padding: EdgeInsets.all(10.0)),
                    ElevatedButton(
                        onPressed: () {
                          req_api("hi");
                        },
                        child: Text('NO'))
                  ],
                ),
              )
            : Container(),
      ],
    );
  }
}







/*

message == "Would you like to add another symptom?"
              ? Container(
                  width: MediaQuery.of(context).size.width * 0.5,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      TextButton(
                          onPressed: () {
                            req_api("yes");
                          },
                          child: Text('YES')),
                      TextButton(
                          onPressed: () {
                            req_api("no");
                          },
                          child: Text('NO'))
                    ],
                  ),
                )
              : Container(),


Do you want to add symptom?

  */