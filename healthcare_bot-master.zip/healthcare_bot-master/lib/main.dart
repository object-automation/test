import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:proto_1/elements/buttons.dart';
import 'package:proto_1/elements/inputs.dart';
import 'package:proto_1/screens/home.dart';
import 'package:proto_1/screens/lang_select.dart';

Future<void> main() async {
  runApp(const MyApp());
  Directory appDocDir = await getApplicationDocumentsDirectory();
  File file = await File("${appDocDir.path}/cache.json").create();
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'HealthCareBot',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: LanguageSelect() //const MyHomePage(title: 'Login'),
        );
  }
}
